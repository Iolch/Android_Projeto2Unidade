package com.example.project2uni

class Note (val title:String, val description:String)